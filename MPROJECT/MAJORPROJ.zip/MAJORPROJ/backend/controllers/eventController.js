const Event = require('../models/Event');
const { recommendEvents } = require('../utils/recommendationEngine');

// Fetch personalized recommendations
exports.getRecommendations = async (req, res) => {
  try {
    const recommendations = await recommendEvents();
    res.json(recommendations);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch recommendations' });
  }
};

// Create a new event
exports.createEvent = async (req, res) => {
  try {
    const event = new Event(req.body);
    await event.save();
    res.json(event);
  } catch (err) {
    res.status(500).json({ error: 'Failed to create event' });
  }
};
