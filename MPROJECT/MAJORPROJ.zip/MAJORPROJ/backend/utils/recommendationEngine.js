const Event = require('../models/Event');

exports.recommendEvents = async () => {
  const events = await Event.find(); // Placeholder for actual AI algorithm
  return events.slice(0, 5); // Return top 5 events
};
