const Sentiment = require('sentiment');
const sentiment = new Sentiment();

exports.analyzeFeedback = (feedback) => {
  return sentiment.analyze(feedback);
};
